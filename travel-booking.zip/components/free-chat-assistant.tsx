"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

type Msg = { role: "user" | "assistant"; content: string }

function localFallback(q: string): string {
  const lower = (q || "").toLowerCase()
  if (/(^|\b)(hi|hii|hello|hey)\b/.test(lower)) {
    return "hii! I can help with flights, buses, and trains. Tell me origin, destination, and date."
  }
  if (lower.includes("time") || lower.includes("timing") || lower.includes("schedule")) {
    return "Typical departure windows: 06:00–10:00, 12:00–15:00, 18:00–22:00. Share route/date for more specific ranges."
  }
  if (lower.includes("baggage") || lower.includes("luggage")) {
    return "Carry-on ~7–10 kg; checked 15–23 kg for economy (varies by airline/fare)."
  }
  if (lower.includes("cancel") || lower.includes("refund")) {
    return "Change/cancel rules depend on fare class and airline. Flexible fares offer better terms."
  }
  if (lower.includes("check-in")) {
    return "Online check-in opens ~24–48h before departure; arrive early if dropping bags."
  }
  if (lower.includes("delay")) {
    return "Check airline status or airport site for live updates; options depend on policy/regulations."
  }
  if (
    lower.includes("bus") ||
    lower.includes("buses") ||
    lower.includes("train") ||
    lower.includes("trains") ||
    lower.includes("rail")
  ) {
    return "I can search buses or trains—please provide origin, destination, and date (e.g., 'train from Seattle to Portland on 2025-10-10')."
  }
  return "I’m here to help with timings, baggage, check-in, delays, and more. Ask me about your route/date/airline—or say 'bus from A to B'."
}

const extractRoute = (q: string) => {
  const m = /from\s+([a-z\s]+?)\s+to\s+([a-z\s]+?)(\s|$)/i.exec(q)
  if (!m) return null
  return { origin: m[1].trim(), destination: m[2].trim() }
}

export default function FreeChatAssistant() {
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      content:
        "Hi! I’m your travel assistant. Ask me about flight timings, baggage, check-in, delays, and more. I work without payment or API keys.",
    },
  ])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const send = async () => {
    const q = input.trim()
    if (!q || loading) return
    setLoading(true)
    setMessages((prev) => [...prev, { role: "user", content: q }])
    setInput("")

    const lower = q.toLowerCase()
    const wantsBus = /(bus|buses)\b/.test(lower)
    const wantsTrain = /(train|trains|rail)\b/.test(lower)
    const route = extractRoute(q)
    const today = new Date().toISOString().slice(0, 10)

    // Try inline search for buses/trains when the query mentions them and we can parse a route
    if (route && (wantsBus || wantsTrain)) {
      try {
        const type = wantsBus ? "buses" : "trains"
        const res = await fetch(
          `/api/search?type=${type}&origin=${encodeURIComponent(route.origin)}&destination=${encodeURIComponent(
            route.destination,
          )}&checkIn=${today}`,
        )
        if (res.ok) {
          const data = (await res.json()) as { items?: Array<any> }
          const items = (data.items || []).slice(0, 3)
          if (items.length > 0) {
            const lines = items.map((it) => {
              const name = it.operator || it.name || it.airline || "Option"
              return `• ${name}: ${it.from} → ${it.to}, depart ${it.depart}, arrive ${it.arrive}, ${it.duration}, $${it.price ?? it.total ?? "—"}`
            })
            setMessages((prev) => [
              ...prev,
              {
                role: "assistant",
                content: `Here are some ${type} options for ${route.origin} → ${route.destination} (top ${items.length}):\n${lines.join(
                  "\n",
                )}\nShare a date/time window to refine.`,
              },
            ])
            setLoading(false)
            return
          }
        }
      } catch {
        // ignore and fall through to assistant endpoint
      }
    }

    // Otherwise call our free assistant API which never requires payment/keys
    try {
      const res = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: q }),
      })

      if (!res.ok) {
        const fallback = localFallback(q)
        setMessages((prev) => [...prev, { role: "assistant", content: fallback }])
      } else {
        const data = (await res.json()) as { reply?: string }
        const reply = (data?.reply || "").trim() || localFallback(q)
        setMessages((prev) => [...prev, { role: "assistant", content: reply }])
      }
    } catch {
      const fallback = localFallback(q)
      setMessages((prev) => [...prev, { role: "assistant", content: fallback }])
    } finally {
      setLoading(false)
      inputRef.current?.focus()
    }
  }

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault()
      send()
    }
  }

  return (
    <Card className="bg-background text-foreground">
      <CardHeader>
        <CardTitle className="text-pretty">Travel Assistant (Free)</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex flex-col gap-3 max-h-[50vh] overflow-y-auto pr-1" aria-live="polite">
          {messages.map((m, i) => (
            <div
              key={i}
              className={m.role === "user" ? "self-end max-w-[80%]" : "self-start max-w-[80%]"}
              role="group"
              aria-label={m.role === "user" ? "Your message" : "Assistant message"}
            >
              <div
                className={
                  m.role === "user"
                    ? "rounded-md px-3 py-2 bg-primary text-primary-foreground"
                    : "rounded-md px-3 py-2 bg-muted text-muted-foreground"
                }
              >
                {m.content}
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <Input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Ask about timings, baggage, check-in..."
            aria-label="Chat message"
          />
          <Button onClick={send} disabled={loading} aria-label="Send message">
            {loading ? "Sending..." : "Send"}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          This assistant works without payment or keys. For exact live data, check your airline or airport site.
        </p>
      </CardContent>
    </Card>
  )
}

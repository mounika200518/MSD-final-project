"use client"

import { useMemo, useRef, useState } from "react"

type Role = "assistant" | "user"
type Mode = "flight" | "bus" | "train"
type Currency = "INR" | "USD"

type Message = { role: Role; content: string }
type Option = {
  id: string
  mode: Mode
  from: string
  to: string
  date: string
  carrier: string
  departTime: string
  arriveTime: string
  duration: string
  stops: number
  refundable: boolean
  baggage: string
  priceINR: number
  priceUSD: number
}

function parseRoute(text: string) {
  const lower = text.toLowerCase()
  let mode: Mode | null = null
  if (lower.includes("flight")) mode = "flight"
  else if (lower.includes("bus")) mode = "bus"
  else if (lower.includes("train")) mode = "train"
  const m = lower.match(/from\s+([a-zA-Z\s]+?)\s+to\s+([a-zA-Z\s]+)/)
  const from = m?.[1]?.trim()
  const to = m?.[2]?.trim()
  return { mode, from, to }
}

function parseDate(text: string) {
  const iso = text.match(/\b\d{4}-\d{2}-\d{2}\b/)
  if (iso) return iso[0]
  const dmy = text.match(/\b(\d{1,2})[/-](\d{1,2})[/-](\d{4})\b/)
  if (dmy) {
    const [_, d, m, y] = dmy
    const dd = d.padStart(2, "0")
    const mm = m.padStart(2, "0")
    return `${y}-${mm}-${dd}`
  }
  const long = text.match(/\b(\d{1,2})\s+([A-Za-z]{3,})\s+(\d{4})\b/)
  if (long) return long[0]
  return null
}

export default function ChatBookingAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hii! I can help you book a flight, bus, or train. Say: “Book a flight from Mumbai to Delhi”.",
    },
  ])
  const [mode, setMode] = useState<Mode | null>(null)
  const [from, setFrom] = useState("")
  const [to, setTo] = useState("")
  const [date, setDate] = useState("")
  const [options, setOptions] = useState<Option[]>([])
  const [selectedOption, setSelectedOption] = useState<Option | null>(null)
  const [fullName, setFullName] = useState("")
  const [email, setEmail] = useState("")
  const [currency, setCurrency] = useState<Currency>("INR")
  const [paymentOk, setPaymentOk] = useState(false)
  const [ticketId, setTicketId] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [input, setInput] = useState("")

  const chatEndRef = useRef<HTMLDivElement>(null)

  const amount = useMemo(() => {
    if (!selectedOption) return 0
    return currency === "INR" ? selectedOption.priceINR : selectedOption.priceUSD
  }, [selectedOption, currency])

  async function pushAssistant(content: string) {
    setMessages((m) => [...m, { role: "assistant", content }])
  }
  async function pushUser(content: string) {
    setMessages((m) => [...m, { role: "user", content }])
  }

  async function handleSend() {
    const text = input.trim()
    if (!text) return
    setInput("")
    await pushUser(text)

    if (/^(hi|hii|hello|hey)\b/i.test(text)) {
      await pushAssistant(
        "hii! What would you like to book — a flight, bus, or train? e.g., “Book a train from Pune to Goa”.",
      )
      return
    }

    if (!mode || !from || !to) {
      const parsed = parseRoute(text)
      if (!parsed.mode) {
        await pushAssistant(
          "Please tell me what to book (flight, bus, train) and the route like “from City A to City B”.",
        )
        return
      }
      if (!parsed.from || !parsed.to) {
        setMode(parsed.mode)
        await pushAssistant(`Got it — ${parsed.mode}. Please provide the route like “from City A to City B”.`)
        return
      }
      setMode(parsed.mode)
      setFrom(parsed.from!)
      setTo(parsed.to!)
      await pushAssistant(
        `Great! ${parsed.mode} from ${parsed.from} to ${parsed.to}. On which date would you like to depart? (e.g., 2025-10-20)`,
      )
      return
    }

    if (mode && from && to && !date) {
      const d = parseDate(text)
      if (!d) {
        await pushAssistant("Please provide your departure date (e.g., 2025-10-20).")
        return
      }
      setDate(d)
      setLoading(true)
      try {
        const url = new URL("/api/free-search", window.location.origin)
        url.searchParams.set("mode", mode)
        url.searchParams.set("from", from)
        url.searchParams.set("to", to)
        url.searchParams.set("date", d)
        const res = await fetch(url.toString(), { cache: "no-store" })
        const data = await res.json()
        setOptions(data.options || [])
        await pushAssistant("Here are options on the right. Pick one, then share your full name and email.")
      } catch {
        await pushAssistant("I couldn’t load options right now. Please try again.")
      } finally {
        setLoading(false)
      }
      return
    }

    if (selectedOption && (!fullName || !email)) {
      if (!fullName && /\s/.test(text) && text.length > 4 && !text.includes("@")) {
        setFullName(text)
        await pushAssistant("Thanks! Please provide your email address.")
        return
      }
      if (!email && /@/.test(text)) {
        setEmail(text)
        await pushAssistant("Got it. Choose your payment currency (INR or USD).")
        return
      }
      await pushAssistant("Please provide your full name and email address.")
      return
    }

    if (selectedOption && fullName && email && !paymentOk && ticketId == null) {
      if (/usd/i.test(text)) {
        setCurrency("USD")
        await pushAssistant(`Currency set to USD. Amount is $${amount}. Click Pay to continue.`)
        return
      }
      if (/inr|rupee|rs/i.test(text)) {
        setCurrency("INR")
        await pushAssistant(`Currency set to INR. Amount is ₹${amount}. Click Pay to continue.`)
        return
      }
      await pushAssistant("Please say “INR” or “USD”, then click Pay.")
      return
    }

    await pushAssistant("Follow steps: select an option, share name/email, pick INR or USD, then click Pay.")
  }

  async function handlePay() {
    if (!selectedOption) return
    setLoading(true)
    try {
      const payRes = await fetch("/api/free-pay", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount, currency }),
      })
      const payData = await payRes.json()
      if (payData.success) {
        setPaymentOk(true)
        await pushAssistant(`Payment successful. Transaction ID: ${payData.txnId}. Confirming your booking...`)
        const bookRes = await fetch("/api/free-book", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ mode, optionId: selectedOption.id, fullName, email, currency, amount }),
        })
        const bookData = await bookRes.json()
        if (bookData.success) {
          setTicketId(bookData.ticketId)
          await pushAssistant(`Booking confirmed! Ticket ID: ${bookData.ticketId}. Have a great trip!`)
        } else {
          await pushAssistant("Booking failed after payment; please try again.")
        }
      } else {
        await pushAssistant("Payment failed. Please try again.")
      }
    } catch {
      await pushAssistant("Payment is currently unavailable. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  function resetAll() {
    setMode(null)
    setFrom("")
    setTo("")
    setDate("")
    setOptions([])
    setSelectedOption(null)
    setFullName("")
    setEmail("")
    setCurrency("INR")
    setPaymentOk(false)
    setTicketId(null)
    setMessages([
      {
        role: "assistant",
        content: "Hii! I can help you book a flight, bus, or train. Say: “Book a flight from Mumbai to Delhi”.",
      },
    ])
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
      <section className="md:col-span-3 flex flex-col rounded-lg border p-4 bg-card text-card-foreground">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold">Chat</h2>
          <button
            onClick={resetAll}
            className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground hover:opacity-90"
          >
            Reset
          </button>
        </div>
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {messages.map((m, i) => (
            <div key={i} className={m.role === "assistant" ? "text-sm" : "text-sm text-primary"}>
              <span className="font-medium">{m.role === "assistant" ? "Assistant: " : "You: "}</span>
              <span>{m.content}</span>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>
        <div className="mt-3 flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type here (e.g., Book a flight from Mumbai to Delhi)"
            className="flex-1 rounded border bg-background px-3 py-2 text-sm outline-none"
          />
          <button
            onClick={handleSend}
            className="rounded bg-primary text-primary-foreground px-4 py-2 text-sm hover:opacity-90"
            disabled={loading}
          >
            Send
          </button>
        </div>

        {selectedOption && (
          <div className="mt-4 space-y-3 border-t pt-4">
            <h3 className="font-medium text-sm">Passenger & Payment</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <input
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Full name"
                className="rounded border bg-background px-3 py-2 text-sm outline-none"
              />
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email address"
                className="rounded border bg-background px-3 py-2 text-sm outline-none"
              />
            </div>
            <div className="flex items-center gap-3">
              <span className="text-sm">Currency:</span>
              <div className="flex gap-2">
                <button
                  onClick={() => setCurrency("INR")}
                  className={`rounded px-3 py-1 text-xs border ${currency === "INR" ? "bg-primary text-primary-foreground" : "bg-background"}`}
                >
                  INR
                </button>
                <button
                  onClick={() => setCurrency("USD")}
                  className={`rounded px-3 py-1 text-xs border ${currency === "USD" ? "bg-primary text-primary-foreground" : "bg-background"}`}
                >
                  USD
                </button>
              </div>
              <div className="ml-auto text-xs">Amount: {currency === "INR" ? `₹${amount}` : `$${amount}`}</div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handlePay}
                className="rounded bg-primary text-primary-foreground px-4 py-2 text-sm hover:opacity-90 disabled:opacity-60"
                disabled={!fullName || !email || !selectedOption || loading || !!ticketId}
              >
                {loading ? "Processing..." : "Pay"}
              </button>
              {paymentOk && !ticketId && (
                <span className="text-xs text-muted-foreground">Payment ok. Confirming booking…</span>
              )}
              {ticketId && <span className="text-xs font-medium">Ticket ID: {ticketId} — Payment completed</span>}
            </div>
          </div>
        )}
      </section>

      <aside className="md:col-span-2 rounded-lg border p-4 bg-card text-card-foreground">
        <h2 className="text-lg font-semibold mb-3">Options</h2>
        <div className="text-xs text-muted-foreground mb-2">
          {mode && from && to && date ? (
            <span>
              {mode} options for {from} → {to} on {date}
            </span>
          ) : (
            <span>Tell me what to book and I’ll show options here.</span>
          )}
        </div>
        {loading && <div className="text-sm">Loading options…</div>}
        {!loading && options.length > 0 && (
          <ul className="space-y-2">
            {options.map((opt) => {
              const active = selectedOption?.id === opt.id
              return (
                <li key={opt.id} className={`rounded border p-3 ${active ? "ring-2 ring-primary" : ""}`}>
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium">
                      {opt.carrier} — {opt.mode.toUpperCase()}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {opt.stops === 0 ? "Nonstop" : `${opt.stops} stop(s)`} · {opt.duration}
                    </div>
                  </div>
                  <div className="text-xs mt-1">
                    {opt.from} {opt.departTime} → {opt.to} {opt.arriveTime}
                  </div>
                  <div className="text-xs mt-1">
                    Baggage: {opt.baggage} · {opt.refundable ? "Refundable" : "Non‑refundable"}
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <div className="text-sm font-semibold">
                      ₹{opt.priceINR} · ${opt.priceUSD}
                    </div>
                    <button
                      onClick={() => {
                        setSelectedOption(opt)
                        setMessages((m) => [
                          ...m,
                          {
                            role: "assistant",
                            content: "Option selected. Please share your full name and email address.",
                          },
                        ])
                      }}
                      className="rounded bg-primary text-primary-foreground px-3 py-1 text-xs hover:opacity-90"
                    >
                      Select
                    </button>
                  </div>
                </li>
              )
            })}
          </ul>
        )}
        {!loading && options.length === 0 && mode && from && to && date && (
          <div className="text-sm">No options found. Try another date or route.</div>
        )}
      </aside>
    </div>
  )
}

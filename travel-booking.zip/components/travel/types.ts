export type Itinerary = {
  id: string
  carrier: string
  from: string
  to: string
  date: string
  departTime: string
  arriveTime: string
  durationMins: number
  priceUSD: number
  seatsLeft: number
}

export type SearchQuery = {
  from: string
  to: string
  date: string
}

export type Ticket = {
  pnr: string
  itineraryId: string
  passengerName: string
  email: string
  createdAt: string
}

"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import type { SearchItem } from "@/components/search-results"

export function BookingDialog({
  open,
  onOpenChange,
  item,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  item: SearchItem | null
}) {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const [ref, setRef] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [emailSent, setEmailSent] = useState<boolean | null>(null)
  const [emailError, setEmailError] = useState<string | null>(null)
  const [amount, setAmount] = useState<string>("")
  const [paying, setPaying] = useState(false)
  const [paymentSuccess, setPaymentSuccess] = useState(false)
  const [paymentMsg, setPaymentMsg] = useState<string | null>(null)
  const [txnId, setTxnId] = useState<string | null>(null)

  const reset = () => {
    setName("")
    setEmail("")
    setSubmitting(false)
    setRef(null)
    setError(null)
    setEmailSent(null)
    setEmailError(null)
    setAmount("")
    setPaying(false)
    setPaymentSuccess(false)
    setPaymentMsg(null)
    setTxnId(null)
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        onOpenChange(v)
        if (!v) reset()
      }}
    >
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Confirm your booking</DialogTitle>
          <DialogDescription>
            {item
              ? item.type === "flight"
                ? `Booking: ${item.airline} • ${item.from} → ${item.to} on ${item.depart}`
                : `Booking: ${item.name} • ${item.city} from ${item.checkIn} to ${item.checkOut}`
              : "No selection"}
          </DialogDescription>
          <p className="mt-2 text-xs text-muted-foreground">
            No real card required. Enter an amount and click Pay to simulate a payment, then confirm your booking.
          </p>
        </DialogHeader>

        {ref ? (
          <div className="grid gap-2">
            <p className="text-sm">
              Success! Your booking reference is <span className="font-mono font-medium">{ref}</span>.
            </p>
            {emailSent ? (
              <p className="text-sm text-muted-foreground">A confirmation email has been sent to {email}.</p>
            ) : (
              <div className="text-sm">
                <p className="text-muted-foreground">
                  We couldn't send a confirmation email right now. Your booking is confirmed.
                </p>
                <p className="text-muted-foreground">
                  Tip: You can screenshot this page. To enable emails, add RESEND_API_KEY and RESEND_FROM_EMAIL in
                  Project Settings and try again.
                </p>
                {emailError ? <p className="text-xs text-destructive">Email error: {emailError}</p> : null}
              </div>
            )}
          </div>
        ) : (
          <>
            <div className="grid gap-3">
              <div className="grid gap-2">
                <Label htmlFor="name">Full name</Label>
                <Input
                  id="name"
                  className="bg-background"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Jane Doe"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  className="bg-background"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="jane@example.com"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="amount">Amount</Label>
                <Input
                  id="amount"
                  className="bg-background"
                  type="number"
                  min={1}
                  placeholder="e.g. 100"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  variant="secondary"
                  disabled={paying || !amount}
                  onClick={async () => {
                    setPaying(true)
                    setPaymentMsg(null)
                    setPaymentSuccess(false)
                    setTxnId(null)
                    try {
                      const res = await fetch("/api/pay", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ amount: Number(amount) }),
                      })
                      const data = await res.json()
                      if (!res.ok) throw new Error(data?.message || "Payment failed")
                      setPaymentSuccess(Boolean(data.success))
                      setPaymentMsg(data.message || (data.success ? "Payment approved" : "Payment declined"))
                      if (data.success && data.txnId) setTxnId(data.txnId)
                    } catch (err: any) {
                      setPaymentSuccess(false)
                      setPaymentMsg(err?.message || "Payment error")
                    } finally {
                      setPaying(false)
                    }
                  }}
                >
                  {paying ? "Paying..." : "Pay"}
                </Button>
                {paymentMsg ? (
                  <span className={`text-sm ${paymentSuccess ? "text-emerald-600" : "text-destructive"}`}>
                    {paymentMsg} {paymentSuccess && txnId ? `(Txn: ${txnId})` : ""}
                  </span>
                ) : null}
              </div>
            </div>

            {error && <p className="text-sm text-destructive">{error}</p>}
          </>
        )}

        <DialogFooter>
          {ref ? (
            <Button onClick={() => onOpenChange(false)}>Close</Button>
          ) : (
            <Button
              disabled={submitting || !item || !name || !email || !paymentSuccess}
              onClick={async () => {
                if (!item) return
                setSubmitting(true)
                setError(null)
                setEmailSent(null)
                setEmailError(null)
                try {
                  const res = await fetch("/api/book", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ item, name, email, txnId }),
                  })
                  const data = await res.json()
                  if (!res.ok) throw new Error(data?.error || "Booking failed")
                  setRef(data.reference)
                  setEmailSent(Boolean(data.emailSent))
                  setEmailError(data.emailError || null)
                } catch (e: any) {
                  setError(e.message || "Something went wrong")
                } finally {
                  setSubmitting(false)
                }
              }}
            >
              {submitting ? "Processing..." : "Confirm Booking"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export type SearchCriteria = {
  type: "flights" | "hotels"
  origin?: string
  destination?: string
  checkIn?: string
  checkOut?: string
  passengers?: number
}

export function SearchForm({
  initial,
  onSearch,
}: {
  initial?: SearchCriteria
  onSearch: (criteria: SearchCriteria) => void
}) {
  const [type, setType] = useState<SearchCriteria["type"]>(initial?.type || "flights")
  const [origin, setOrigin] = useState(initial?.origin || "")
  const [destination, setDestination] = useState(initial?.destination || "")
  const [checkIn, setCheckIn] = useState(initial?.checkIn || "")
  const [checkOut, setCheckOut] = useState(initial?.checkOut || "")
  const [passengers, setPassengers] = useState(initial?.passengers || 1)

  return (
    <form
      className="grid gap-3"
      onSubmit={(e) => {
        e.preventDefault()
        onSearch({
          type,
          origin: origin || undefined,
          destination: destination || undefined,
          checkIn: checkIn || undefined,
          checkOut: checkOut || undefined,
          passengers,
        })
      }}
    >
      <div className="grid gap-2">
        <Label htmlFor="type">Search for</Label>
        <Select value={type} onValueChange={(v) => setType(v as any)}>
          <SelectTrigger id="type" className="bg-background">
            <SelectValue placeholder="Choose type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="flights">Flights</SelectItem>
            <SelectItem value="hotels">Hotels</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="grid gap-2">
          <Label htmlFor="origin">{type === "flights" ? "Origin" : "City"}</Label>
          <Input
            id="origin"
            className="bg-background"
            placeholder={type === "flights" ? "SFO" : "San Francisco"}
            value={origin}
            onChange={(e) => setOrigin(e.target.value)}
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="destination">{type === "flights" ? "Destination" : "Area"}</Label>
          <Input
            id="destination"
            className="bg-background"
            placeholder={type === "flights" ? "LAX" : "Downtown"}
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="grid gap-2">
          <Label htmlFor="checkIn">{type === "flights" ? "Depart" : "Check-in"}</Label>
          <Input
            id="checkIn"
            className="bg-background"
            type="date"
            value={checkIn}
            onChange={(e) => setCheckIn(e.target.value)}
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="checkOut">{type === "flights" ? "Return (optional)" : "Check-out"}</Label>
          <Input
            id="checkOut"
            className="bg-background"
            type="date"
            value={checkOut}
            onChange={(e) => setCheckOut(e.target.value)}
          />
        </div>
      </div>

      <div className="grid gap-2">
        <Label htmlFor="passengers">{type === "flights" ? "Passengers" : "Guests"}</Label>
        <Input
          id="passengers"
          className="bg-background"
          type="number"
          min={1}
          value={passengers}
          onChange={(e) => setPassengers(Number(e.target.value) || 1)}
        />
      </div>

      <Button type="submit" className="mt-1">
        Search
      </Button>
    </form>
  )
}

"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"

type Msg = { role: "user" | "assistant"; content: string }

export function ChatAssistant() {
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: "Hi! Ask me anything about your trip." },
  ])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)

  function localFallback(q: string): string {
    const text = (q || "").toLowerCase()
    const tips =
      "- Share from/to cities and dates for better options.\n- Flexible dates often reduce prices.\n- Off-peak times can be cheaper.\n- Compare nearby airports or neighborhoods."
    if (text.includes("cancel")) {
      return "To cancel, share your booking reference (e.g., BK-XXXX). Many fares allow 24h cancellation. Hotels depend on their window."
    }
    if (text.includes("change") || text.includes("modify")) {
      return "To change a booking, provide your reference plus new dates/route. Changes may incur a fee depending on fare rules."
    }
    if (text.includes("baggage")) {
      return "Baggage policies vary. Typically 1 small personal item is free; carry-on/checked often have fees on basic fares."
    }
    if (text.includes("refund")) {
      return "Refunds depend on fare type and policy. Many basic fares are nonrefundable, but you may get credit. Share your reference for help."
    }
    return `Here are some quick tips:\n${tips}\n\nAsk about flights, hotels, or share a booking reference for more specific help.`
  }

  const send = async () => {
    const text = input.trim()
    if (!text) return
    const next = [...messages, { role: "user", content: text } as Msg]
    setMessages(next)
    setInput("")
    setLoading(true)
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next }),
      })
      let reply = ""
      if (res.ok) {
        const data = await res.json().catch(() => null as any)
        if (data?.reply && typeof data.reply === "string") {
          reply = data.reply
        }
      }
      if (!reply) {
        reply = localFallback(text)
      }
      setMessages([...next, { role: "assistant", content: reply }])
    } catch {
      setMessages([...next, { role: "assistant", content: localFallback(text) }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="mt-4 p-3">
      <h3 className="mb-1 text-sm font-medium">AI Assistant</h3>
      <p className="mb-2 text-xs text-muted-foreground">Free assistant — no payment required.</p>
      <div className="mb-3 max-h-56 overflow-auto rounded-md border border-border bg-card p-2 text-sm">
        {messages.map((m, i) => (
          <div key={i} className={m.role === "user" ? "text-right" : "text-left"}>
            <span
              className={
                m.role === "user"
                  ? "inline-block rounded-md bg-primary px-2 py-1 text-primary-foreground"
                  : "inline-block rounded-md bg-muted px-2 py-1 text-foreground"
              }
            >
              {m.content}
            </span>
          </div>
        ))}
      </div>
      <div className="flex items-center gap-2">
        <Input
          className="bg-background"
          placeholder="Ask about flights, hotels, or bookings..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") send()
          }}
        />
        <Button onClick={send} disabled={loading}>
          {loading ? "Thinking..." : "Send"}
        </Button>
      </div>
    </Card>
  )
}

"use client"

import useSWR from "swr"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import type { SearchCriteria } from "@/components/search-form"

export type SearchItem =
  | {
      id: string
      type: "flight"
      airline: string
      from: string
      to: string
      depart: string
      arrive: string
      duration: string
      price: number
    }
  | {
      id: string
      type: "hotel"
      name: string
      city: string
      rating: number
      checkIn: string
      checkOut: string
      pricePerNight: number
      nights: number
      total: number
    }

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export function SearchResults({
  criteria,
  onSelect,
}: {
  criteria: SearchCriteria | null
  onSelect: (item: SearchItem) => void
}) {
  const params = new URLSearchParams()
  if (criteria?.type) params.set("type", criteria.type)
  if (criteria?.origin) params.set("origin", criteria.origin)
  if (criteria?.destination) params.set("destination", criteria.destination)
  if (criteria?.checkIn) params.set("checkIn", criteria.checkIn)
  if (criteria?.checkOut) params.set("checkOut", criteria.checkOut)
  if (criteria?.passengers) params.set("passengers", String(criteria.passengers))

  const shouldFetch = Boolean(criteria)
  const { data, error, isLoading } = useSWR(shouldFetch ? `/api/search?${params.toString()}` : null, fetcher)

  if (!criteria) {
    return <div className="mt-4 text-sm text-muted-foreground">Enter your search criteria to see results.</div>
  }

  if (isLoading) {
    return (
      <div className="mt-4 grid gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-24 w-full" />
        ))}
      </div>
    )
  }

  if (error) {
    return <div className="mt-4 text-sm text-destructive">Something went wrong while fetching results.</div>
  }

  if (!data || !Array.isArray(data.items) || data.items.length === 0) {
    return <div className="mt-4 text-sm text-muted-foreground">No results found. Try adjusting your criteria.</div>
  }

  return (
    <div className="mt-4 grid gap-3">
      {data.items.map((item: SearchItem) => (
        <Card key={item.id} className="flex items-center justify-between p-3 md:p-4">
          <div className="text-sm">
            {item.type === "flight" ? (
              <div>
                <div className="font-medium">
                  {item.airline} • {item.from} → {item.to}
                </div>
                <div className="text-muted-foreground">
                  {item.depart} → {item.arrive} • {item.duration}
                </div>
                <div className="mt-1 font-medium">${item.price}</div>
              </div>
            ) : (
              <div>
                <div className="font-medium">
                  {item.name} • {item.city} • {item.rating.toFixed(1)}★
                </div>
                <div className="text-muted-foreground">
                  {item.checkIn} → {item.checkOut} • {item.nights} nights
                </div>
                <div className="mt-1 font-medium">${item.total}</div>
              </div>
            )}
          </div>
          <Button variant="default" onClick={() => onSelect(item)}>
            Book
          </Button>
        </Card>
      ))}
    </div>
  )
}

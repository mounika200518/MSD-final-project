"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export type ClearSearchParams = {
  mode: "flight" | "bus" | "train"
  from: string
  to: string
  date: string
  passengers: number
}

export function ClearSearchForm({
  initial,
  onSearch,
}: {
  initial?: Partial<ClearSearchParams>
  onSearch: (params: ClearSearchParams) => void
}) {
  const [mode, setMode] = useState<ClearSearchParams["mode"]>(initial?.mode || "flight")
  const [from, setFrom] = useState(initial?.from || "")
  const [to, setTo] = useState(initial?.to || "")
  const [date, setDate] = useState(initial?.date || "")
  const [passengers, setPassengers] = useState(initial?.passengers || 1)

  function submit(e: React.FormEvent) {
    e.preventDefault()
    onSearch({
      mode,
      from: from.trim(),
      to: to.trim(),
      date,
      passengers: Math.max(1, Number(passengers || 1)),
    })
  }

  return (
    <form onSubmit={submit} className="rounded-lg border bg-card p-4 text-card-foreground">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-5">
        <div className="space-y-2 md:col-span-1">
          <Label htmlFor="mode">Mode</Label>
          <Select value={mode} onValueChange={(v) => setMode(v as any)}>
            <SelectTrigger id="mode" aria-label="Travel mode">
              <SelectValue placeholder="Select mode" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="flight">Flights</SelectItem>
              <SelectItem value="bus">Buses</SelectItem>
              <SelectItem value="train">Trains</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2 md:col-span-1">
          <Label htmlFor="from">From</Label>
          <Input id="from" value={from} onChange={(e) => setFrom(e.target.value)} placeholder="City or code" />
        </div>

        <div className="space-y-2 md:col-span-1">
          <Label htmlFor="to">To</Label>
          <Input id="to" value={to} onChange={(e) => setTo(e.target.value)} placeholder="City or code" />
        </div>

        <div className="space-y-2 md:col-span-1">
          <Label htmlFor="date">Date</Label>
          <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>

        <div className="space-y-2 md:col-span-1">
          <Label htmlFor="passengers">Passengers</Label>
          <Input
            id="passengers"
            type="number"
            min={1}
            value={passengers}
            onChange={(e) => setPassengers(Number(e.target.value))}
          />
        </div>
      </div>

      <div className="mt-4 flex items-center justify-end">
        <Button type="submit" className="bg-primary text-primary-foreground hover:opacity-90">
          Search
        </Button>
      </div>
    </form>
  )
}

"use client"

import useSWR from "swr"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import type { ClearSearchParams } from "./clear-search-form"

type ResultBase = {
  id: string
  type: "flight" | "bus" | "train"
  provider: string
  number: string
  from: string
  to: string
  date: string
  departTime: string
  arriveTime: string
  durationMin: number
  stops: number
  seatsLeft: number
  baggage: string
  refundable: boolean
  price: number
  currency: string
  notes?: string
  class?: string
}

function fetcher(url: string) {
  return fetch(url).then((r) => r.json())
}

function fmtDuration(mins: number) {
  const h = Math.floor(mins / 60)
  const m = mins % 60
  return `${h}h ${m}m`
}

export function ClearSearchResults({
  params,
  onSelect,
}: {
  params?: ClearSearchParams
  onSelect?: (r: ResultBase) => void
}) {
  const query = params
    ? new URLSearchParams({
        mode: params.mode,
        from: params.from,
        to: params.to,
        date: params.date,
        passengers: String(params.passengers),
      }).toString()
    : ""

  const { data, error, isLoading } = useSWR(params ? `/api/search-clear?${query}` : null, fetcher, {
    revalidateOnFocus: false,
  })

  if (!params) {
    return (
      <div className="rounded-lg border bg-muted/30 p-6 text-muted-foreground">
        Enter your trip details and click Search to see results.
      </div>
    )
  }

  if (isLoading) {
    return <div className="animate-pulse rounded-lg border bg-card p-6 text-card-foreground">Loading results…</div>
  }

  if (error) {
    return (
      <div className="rounded-lg border bg-destructive/10 p-6 text-destructive-foreground">
        Could not load results. Please try again.
      </div>
    )
  }

  const results: ResultBase[] = data?.results || []
  if (!results.length) {
    return (
      <div className="rounded-lg border bg-muted/30 p-6 text-muted-foreground">
        No results found. Adjust your search and try again.
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 gap-4">
      {results.map((r) => (
        <Card key={r.id} className="overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-balance text-lg">
              {r.type === "flight" ? "Flight" : r.type === "bus" ? "Bus" : "Train"} • {r.provider} {r.number}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge variant="outline">{r.refundable ? "Refundable" : "Non‑refundable"}</Badge>
              <Badge variant="secondary">{r.seatsLeft} seats left</Badge>
            </div>
          </CardHeader>
          <CardContent className="grid grid-cols-1 items-start gap-4 md:grid-cols-4">
            <div className="space-y-1">
              <div className="text-sm text-muted-foreground">Route</div>
              <div className="text-pretty font-medium">
                {r.from} → {r.to}
              </div>
              <div className="text-xs text-muted-foreground">{r.date}</div>
            </div>

            <div className="space-y-1">
              <div className="text-sm text-muted-foreground">Timings</div>
              <div className="font-medium">
                {r.departTime} → {r.arriveTime}
              </div>
              <div className="text-xs text-muted-foreground">
                Duration {fmtDuration(r.durationMin)} • {r.stops ? `${r.stops} stop` : "Non‑stop"}
              </div>
            </div>

            <div className="space-y-1">
              <div className="text-sm text-muted-foreground">Details</div>
              <div className="text-sm">{r.baggage}</div>
              {r.class && <div className="text-sm">Class: {r.class}</div>}
              {r.notes && <div className="text-xs text-muted-foreground">{r.notes}</div>}
            </div>

            <div className="flex flex-col items-end justify-between gap-2">
              <div className="text-right">
                <div className="text-2xl font-semibold">
                  {r.currency} {r.price.toLocaleString()}
                </div>
                <div className="text-xs text-muted-foreground">Total for party</div>
              </div>
              <Button onClick={() => onSelect?.(r)} className="bg-primary text-primary-foreground hover:opacity-90">
                Select
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { SearchForm, type SearchCriteria } from "@/components/search-form"
import { SearchResults, type SearchItem } from "@/components/search-results"
import { BookingDialog } from "@/components/booking-dialog"
import { ChatAssistant } from "@/components/chat-assistant"

export function TravelApp() {
  const [criteria, setCriteria] = useState<SearchCriteria | null>(null)
  const [selected, setSelected] = useState<SearchItem | null>(null)
  const [bookingOpen, setBookingOpen] = useState(false)

  return (
    <div className="grid gap-6 md:grid-cols-3">
      <Card className="col-span-1 p-4 md:p-6">
        <h2 className="mb-2 text-lg font-medium">Search</h2>
        <p className="mb-4 text-sm text-muted-foreground">Find flights or hotels using simple filters.</p>
        <SearchForm initial={criteria || undefined} onSearch={(c) => setCriteria(c)} />
        <Separator className="my-4" />
        <ChatAssistant />
      </Card>

      <Card className="col-span-2 p-4 md:p-6">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-medium">Results</h2>
          <p className="text-xs text-muted-foreground">{"Powered by a demo generator"}</p>
        </div>

        <SearchResults
          criteria={criteria}
          onSelect={(item) => {
            setSelected(item)
            setBookingOpen(true)
          }}
        />

        <BookingDialog open={bookingOpen} onOpenChange={setBookingOpen} item={selected} />
      </Card>
    </div>
  )
}

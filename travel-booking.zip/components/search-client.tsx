"use client"

import { useState } from "react"
import { ClearSearchForm, type ClearSearchParams } from "./clear-search-form"
import { ClearSearchResults } from "./clear-search-results"

export default function SearchClient() {
  const [params, setParams] = useState<ClearSearchParams | undefined>(undefined)

  return (
    <div className="space-y-4">
      <ClearSearchForm onSearch={setParams} />
      <ClearSearchResults
        params={params}
        onSelect={(r) => {
          console.log("[v0] Selected result:", r)
          alert(
            `Selected ${r.type.toUpperCase()} • ${r.provider} ${r.number}\n${r.from} → ${r.to} on ${r.date}\n${r.departTime} → ${r.arriveTime}\nPrice: ${r.currency} ${r.price.toLocaleString()}`,
          )
        }}
      />
    </div>
  )
}

import SearchClient from "@/components/search-client"

export default function Page() {
  return (
    <main className="container mx-auto max-w-5xl space-y-6 px-4 py-8">
      <header className="space-y-1">
        <h1 className="text-balance text-2xl font-semibold">Find clear, detailed travel options</h1>
        <p className="text-pretty text-sm text-muted-foreground">
          Search flights, buses, and trains with clean timings, duration, stops, baggage/refund info, and total price.
        </p>
      </header>

      <SearchClient />
    </main>
  )
}

import { NextResponse } from "next/server"

export async function POST(req: Request) {
  const body = await req.json().catch(() => null)
  if (!body?.item || !body?.name || !body?.email) {
    return NextResponse.json({ error: "Missing fields" }, { status: 400 })
  }

  // Simulate payment/processing delay
  await new Promise((r) => setTimeout(r, 700))

  const reference = `BK-${Date.now().toString(36).toUpperCase()}-${Math.floor(Math.random() * 9999)
    .toString()
    .padStart(4, "0")}`

  let emailSent = false
  let emailError: string | null = null

  try {
    if (process.env.RESEND_API_KEY && process.env.RESEND_FROM_EMAIL) {
      const itemSummary =
        typeof body?.item === "object"
          ? JSON.stringify(
              {
                id: body.item.id,
                type: body.item.type,
                from: body.item.from,
                to: body.item.to,
                name: body.item.name,
                city: body.item.city,
                depart: body.item.depart,
                arrive: body.item.arrive,
                checkIn: body.item.checkIn,
                checkOut: body.item.checkOut,
              },
              null,
              2,
            )
          : String(body?.item)

      const resp = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        },
        body: JSON.stringify({
          from: process.env.RESEND_FROM_EMAIL,
          to: body.email,
          subject: `Your booking confirmation (${reference})`,
          text: `Hi ${body.name},\n\nThanks for your booking!\n\nReference: ${reference}\n\nDetails:\n${itemSummary}\n\nIf you have any questions, just reply to this email.\n`,
        }),
      })

      emailSent = resp.ok
      if (!resp.ok) {
        const t = await resp.text().catch(() => "")
        emailError = t || `Email provider error (${resp.status})`
      }
    }
  } catch (e: any) {
    emailError = e?.message || "Email send failed"
  }

  return NextResponse.json({ reference, emailSent, emailError })
}

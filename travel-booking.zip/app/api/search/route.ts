import { NextResponse } from "next/server"

function randInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

const airlines = ["AirOne", "SkyJet", "AeroGo", "CloudAir", "FlyFast"]
const cities = ["San Francisco", "Los Angeles", "New York", "Seattle", "Chicago", "Austin", "Miami"]
const operatorsBuses = ["InterCity", "MegaBus", "GreyLine", "RoadRunner"]
const operatorsTrains = ["National Rail", "ExpressLine", "RapidRail", "MetroLink"]

export async function GET(req: Request) {
  const url = new URL(req.url)
  const type = (url.searchParams.get("type") || "flights") as "flights" | "hotels" | "buses" | "trains"
  const origin = url.searchParams.get("origin") || "San Francisco"
  const destination = url.searchParams.get("destination") || "Los Angeles"
  const checkIn = url.searchParams.get("checkIn") || new Date().toISOString().slice(0, 10)
  const checkOut = url.searchParams.get("checkOut") || new Date(Date.now() + 86400000).toISOString().slice(0, 10)
  const passengers = Number(url.searchParams.get("passengers") || 1)

  if (type === "flights") {
    const items = Array.from({ length: 8 }).map((_, i) => {
      const price = 80 + randInt(0, 320) + passengers * 20
      const departHour = 6 + randInt(0, 12)
      const durationH = 1 + randInt(0, 4)
      const arriveHour = departHour + durationH
      return {
        id: `flt_${i}_${Date.now()}`,
        type: "flight" as const,
        airline: airlines[randInt(0, airlines.length - 1)],
        from: origin.toUpperCase(),
        to: destination.toUpperCase(),
        depart: `${checkIn} ${String(departHour).padStart(2, "0")}:00`,
        arrive: `${checkIn} ${String(arriveHour).padStart(2, "0")}:00`,
        duration: `${durationH}h ${randInt(0, 3) * 15}m`,
        price,
      }
    })
    return NextResponse.json({ items })
  }

  if (type === "buses") {
    const items = Array.from({ length: 6 }).map((_, i) => {
      const price = 15 + randInt(0, 35) + passengers * 5
      const departHour = 6 + randInt(0, 14)
      const durationH = 6 + randInt(0, 6)
      const arriveHour = departHour + durationH
      return {
        id: `bus_${i}_${Date.now()}`,
        type: "bus" as const,
        operator: operatorsBuses[randInt(0, operatorsBuses.length - 1)],
        from: origin,
        to: destination,
        depart: `${checkIn} ${String(departHour).padStart(2, "0")}:00`,
        arrive: `${checkIn} ${String(arriveHour).padStart(2, "0")}:00`,
        duration: `${durationH}h ${randInt(0, 3) * 15}m`,
        price,
      }
    })
    return NextResponse.json({ items })
  }

  if (type === "trains") {
    const items = Array.from({ length: 6 }).map((_, i) => {
      const price = 20 + randInt(0, 50) + passengers * 7
      const departHour = 5 + randInt(0, 16)
      const durationH = 3 + randInt(0, 8)
      const arriveHour = departHour + durationH
      return {
        id: `trn_${i}_${Date.now()}`,
        type: "train" as const,
        operator: operatorsTrains[randInt(0, operatorsTrains.length - 1)],
        from: origin,
        to: destination,
        depart: `${checkIn} ${String(departHour).padStart(2, "0")}:00`,
        arrive: `${checkIn} ${String(arriveHour).padStart(2, "0")}:00`,
        duration: `${durationH}h ${randInt(0, 3) * 15}m`,
        price,
      }
    })
    return NextResponse.json({ items })
  }

  // hotels
  const start = new Date(checkIn)
  const end = new Date(checkOut)
  const nights = Math.max(1, Math.round((+end - +start) / 86400000))
  const city = cities[randInt(0, cities.length - 1)]
  const items = Array.from({ length: 8 }).map((_, i) => {
    const price = 70 + randInt(0, 180)
    return {
      id: `htl_${i}_${Date.now()}`,
      type: "hotel" as const,
      name: `Hotel ${String.fromCharCode(65 + i)}`,
      city: destination || city,
      rating: Math.max(3, Math.min(5, Number((3 + Math.random() * 2).toFixed(1)))),
      checkIn,
      checkOut,
      pricePerNight: price,
      nights,
      total: price * nights,
    }
  })
  return NextResponse.json({ items })
}

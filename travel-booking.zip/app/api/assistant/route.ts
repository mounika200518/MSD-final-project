import { NextResponse } from "next/server"

type ChatBody = {
  message?: string
  messages?: Array<{ role: "user" | "assistant" | "system"; content: string }>
  context?: Record<string, unknown>
}

function ruleBasedAnswer(qRaw: string): string {
  const q = (qRaw || "").toLowerCase().trim()
  const has = (...keys: string[]) => keys.some((k) => q.includes(k))

  // Greetings
  if (has("hi", "hii", "hello", "hey")) {
    return [
      "hii! I’m your travel assistant.",
      "I can help with flight timings, baggage, check-in, delays, cancellations, and I can also help you find buses and trains.",
      "Tell me your origin, destination, and date to search.",
    ].join(" ")
  }

  // Buses / Trains
  if (has("bus", "buses", "train", "trains", "rail")) {
    return [
      "I can help you find buses and trains.",
      "Please provide origin, destination, and date (e.g., 'bus from San Francisco to Los Angeles on 2025-10-10').",
      "I’ll list options and timings for you.",
    ].join(" ")
  }

  // Flight timings
  if (has("time", "timing", "schedule", "depart", "arrival", "arrive", "duration")) {
    return [
      "Typical flight schedules vary by route and weekday.",
      "Common departure windows are 06:00–10:00, 12:00–15:00, and 18:00–22:00 local time.",
      "For exact timings on your route, please provide origin, destination, and date, or check your airline’s schedule.",
      "If you already have a booking, your PNR/confirmation shows the official times (local to each airport).",
    ].join(" ")
  }

  // Baggage
  if (has("baggage", "luggage", "bag", "carry-on", "checked")) {
    return [
      "Carry-on is usually ~7–10 kg with size limits around 55×35×25 cm; checked baggage often ranges 15–23 kg for economy.",
      "Rules differ by fare class and airline.",
      "Please share your airline and fare type for precise allowance, or check your booking email/PNR.",
    ].join(" ")
  }

  // Cancellation / refund / reschedule
  if (has("cancel", "cancellation", "refund", "reschedule", "change")) {
    return [
      "Most standard economy fares can be changed or canceled with a fee; flexible fares offer better terms.",
      "Refunds depend on airline policy and fare rules.",
      "Share your airline and fare class for tailored guidance, or check the fare rules in your confirmation.",
    ].join(" ")
  }

  // Check-in
  if (has("check-in", "checkin", "boarding pass")) {
    return [
      "Online check-in typically opens 24–48 hours before departure.",
      "Airport counters usually open ~3 hours prior for international and ~2 hours for domestic.",
      "Arrive early if you need to drop bags or require special assistance.",
    ].join(" ")
  }

  // Delay / disruption
  if (has("delay", "delayed", "late", "cancelled", "diverted")) {
    return [
      "For live delay info, check your airline’s status page or the airport website.",
      "Compensation depends on local regulations and airline policy.",
      "If you share your airline and route, I can outline typical options.",
    ].join(" ")
  }

  // Visas / documents
  if (has("visa", "passport", "document", "id")) {
    return [
      "Entry requirements vary by nationality and destination.",
      "Always verify via the destination government website or IATA Travel Centre.",
      "Ensure your passport has required validity (often 6 months) and any needed visas.",
    ].join(" ")
  }

  // Seats / pricing
  if (has("seat", "seating", "window", "aisle", "price", "fare", "cost")) {
    return [
      "Seat selection is often available during or after booking; some fares charge a fee.",
      "Prices fluctuate based on demand, season, and advance purchase.",
      "Share your route and dates for a rough estimate or use the search to compare options.",
    ].join(" ")
  }

  // Default helpful fallback
  return [
    "I’m your travel assistant. I can help with flight timings, baggage rules, check-in, delays, cancellations, and more.",
    "Ask me about your route, date, airline, or PNR for more specific guidance.",
    "This assistant works without any payment or API keys.",
  ].join(" ")
}

export async function POST(req: Request) {
  let body: ChatBody
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ reply: ruleBasedAnswer("") })
  }

  const userMessage =
    body?.message ??
    body?.messages
      ?.slice()
      .reverse()
      .find((m) => m.role === "user")?.content ??
    ""

  const reply = ruleBasedAnswer(userMessage || "")
  return NextResponse.json({ reply })
}

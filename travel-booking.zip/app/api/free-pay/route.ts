export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}))
  const amount = Number(body?.amount || 0)
  const currency = (body?.currency || "INR") as "INR" | "USD"
  if (!amount || amount <= 0) {
    return new Response(JSON.stringify({ success: false, error: "Invalid amount" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    })
  }
  const txnId = `TXN-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`
  return Response.json({ success: true, txnId, currency, amount })
}

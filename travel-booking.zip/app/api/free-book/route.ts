export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}))
  const mode = body?.mode as "flight" | "bus" | "train"
  const optionId = body?.optionId as string
  const fullName = body?.fullName as string
  const email = body?.email as string
  const currency = (body?.currency || "INR") as "INR" | "USD"
  const amount = Number(body?.amount || 0)

  if (!mode || !optionId || !fullName || !email || !amount) {
    return new Response(JSON.stringify({ success: false, error: "Missing required fields" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    })
  }

  const ticketId = `TKT-${mode.slice(0, 1).toUpperCase()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`
  const issuedAt = new Date().toISOString()
  return Response.json({ success: true, ticketId, currency, amount, issuedAt, contact: { fullName, email } })
}

import { NextResponse } from "next/server"

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}))
    const amountRaw = body?.amount
    const amount = Number(amountRaw)

    if (!Number.isFinite(amount) || amount <= 0) {
      return NextResponse.json(
        { success: false, message: "Invalid amount. Enter a number greater than 0." },
        { status: 400 },
      )
    }

    // 80% success rate for dummy payment
    const success = Math.random() < 0.8
    const txnId = "txn_" + Math.random().toString(36).slice(2, 8) + Math.random().toString(36).slice(2, 8)

    return NextResponse.json({
      success,
      txnId,
      amount,
      message: success ? "Payment approved" : "Payment declined. Try again.",
      processedAt: new Date().toISOString(),
    })
  } catch {
    return NextResponse.json({ success: false, message: "Payment service error" }, { status: 500 })
  }
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const mode = (searchParams.get("mode") || "flight") as "flight" | "bus" | "train"
  const from = (searchParams.get("from") || "City A").trim()
  const to = (searchParams.get("to") || "City B").trim()
  const date = (searchParams.get("date") || "2025-10-20").trim()

  const seed = (from + to + date + mode).split("").reduce((a, c) => a + c.charCodeAt(0), 0)
  function rand(n: number) {
    return Math.abs(Math.sin(seed + n)) % 1
  }

  const carriers =
    mode === "flight"
      ? ["IndiGo", "Air India", "Vistara", "SpiceJet", "Akasa"]
      : mode === "bus"
        ? ["RedBus", "VRL", "Orange", "SRS", "KSRTC"]
        : ["IRCTC", "Shatabdi", "Duronto", "Rajdhani", "Intercity"]

  const options = Array.from({ length: 5 }).map((_, i) => {
    const depHour = 6 + Math.floor(rand(i) * 14)
    const depMin = Math.floor(rand(i + 1) * 60)
    const durHours = 1 + Math.floor(rand(i + 2) * (mode === "flight" ? 3 : mode === "train" ? 10 : 8))
    const durMins = [0, 15, 30, 45][Math.floor(rand(i + 3) * 4)]
    const arrHour = (depHour + durHours) % 24
    const arrMin = (depMin + durMins) % 60
    const stops = mode === "flight" ? (Math.floor(rand(i + 4) * 3) === 0 ? 0 : 1) : 0
    const refundable = Math.floor(rand(i + 5) * 2) === 0
    const baggage = mode === "flight" ? "15kg + cabin" : mode === "train" ? "2 bags" : "1 bag"
    const base = mode === "flight" ? 3500 : mode === "train" ? 900 : 700
    const priceINR = base + Math.floor(rand(i + 6) * base * 2)
    const priceUSD = Math.round(priceINR / 83)
    const pad = (n: number) => String(n).padStart(2, "0")
    return {
      id: `${mode}-${i + 1}`,
      mode,
      from,
      to,
      date,
      carrier: carriers[i % carriers.length],
      departTime: `${pad(depHour)}:${pad(depMin)}`,
      arriveTime: `${pad(arrHour)}:${pad(arrMin)}`,
      duration: `${durHours}h ${durMins}m`,
      stops,
      refundable,
      baggage,
      priceINR,
      priceUSD,
    }
  })

  return Response.json({ options })
}

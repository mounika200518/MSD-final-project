import { NextResponse } from "next/server"

type Mode = "flight" | "bus" | "train"

function randInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function pick<T>(arr: T[]) {
  return arr[randInt(0, arr.length - 1)]
}

function addMinutes(base: string, minutes: number) {
  // base 'HH:MM'
  const [h, m] = base.split(":").map(Number)
  const d = new Date()
  d.setHours(h, m, 0, 0)
  d.setMinutes(d.getMinutes() + minutes)
  const hh = String(d.getHours()).padStart(2, "0")
  const mm = String(d.getMinutes()).padStart(2, "0")
  return `${hh}:${mm}`
}

export async function GET(req: Request) {
  const url = new URL(req.url)
  const mode = (url.searchParams.get("mode") as Mode) || "flight"
  const from = (url.searchParams.get("from") || "New York").trim()
  const to = (url.searchParams.get("to") || "Boston").trim()
  const date = (url.searchParams.get("date") || "2025-10-14").trim()
  const passengers = Math.max(1, Number(url.searchParams.get("passengers") || 1))

  const starts = ["05:30", "07:15", "09:00", "12:45", "15:20", "18:10", "20:00"]
  const carriers = ["SkyFly", "AirFast", "JetStar", "AeroGo"]
  const busOps = ["RoadRunner", "InterCity", "MegaBus"]
  const trainOps = ["NationalRail", "ExpressLine", "MetroRail"]

  const results = Array.from({ length: 5 }).map((_, i) => {
    const departTime = pick(starts)
    const durationMin = mode === "flight" ? randInt(60, 240) : mode === "bus" ? randInt(90, 420) : randInt(75, 360)
    const arriveTime = addMinutes(departTime, durationMin)
    const stops = mode === "flight" ? pick([0, 0, 1]) : pick([0, 0, 0, 1])
    const seatsLeft = randInt(3, 22)
    const refundable = pick([true, false])
    const baggage = mode === "flight" ? "Cabin 7kg + 15kg check-in" : "1 small bag"
    const currency = "USD"
    const basePrice = mode === "flight" ? randInt(79, 299) : mode === "bus" ? randInt(15, 59) : randInt(19, 89)
    const price = basePrice * passengers

    if (mode === "flight") {
      const provider = pick(carriers)
      return {
        id: `flt-${i}`,
        type: "flight",
        provider,
        number: `${provider.slice(0, 2).toUpperCase()}${randInt(100, 999)}`,
        from,
        to,
        date,
        departTime,
        arriveTime,
        durationMin,
        stops,
        seatsLeft,
        baggage,
        refundable,
        price,
        currency,
        notes: stops > 0 ? "Includes one short layover" : "Non-stop flight",
      }
    }

    if (mode === "bus") {
      const provider = pick(busOps)
      return {
        id: `bus-${i}`,
        type: "bus",
        provider,
        number: `${provider.slice(0, 2).toUpperCase()}B${randInt(100, 999)}`,
        class: pick(["Standard", "Comfort", "Sleeper"]),
        from,
        to,
        date,
        departTime,
        arriveTime,
        durationMin,
        stops,
        seatsLeft,
        baggage,
        refundable,
        price,
        currency,
        notes: stops > 0 ? "One rest stop on route" : "Non-stop coach",
      }
    }

    // train
    const provider = pick(trainOps)
    return {
      id: `trn-${i}`,
      type: "train",
      provider,
      number: `${provider.slice(0, 2).toUpperCase()}T${randInt(100, 999)}`,
      class: pick(["2nd Class", "1st Class", "Business"]),
      from,
      to,
      date,
      departTime,
      arriveTime,
      durationMin,
      stops,
      seatsLeft,
      baggage,
      refundable,
      price,
      currency,
      notes: stops > 0 ? "One intermediate stop" : "Direct service",
    }
  })

  return NextResponse.json({
    query: { mode, from, to, date, passengers },
    results,
    meta: {
      disclaimer: "All results are sample data for demo purposes. Times and prices are approximate.",
    },
  })
}

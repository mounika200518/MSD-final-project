import { NextResponse } from "next/server"
import { generateText } from "ai"

export async function POST(req: Request) {
  const { messages } = await req.json()

  const promptBase =
    "You are a concise travel assistant. Be practical, accurate, and helpful. Use short paragraphs and bullet points where useful."

  let userLatest = "Hello"
  if (Array.isArray(messages) && messages.length > 0) {
    const last = messages[messages.length - 1]
    if (last?.role === "user" && typeof last?.content === "string") {
      userLatest = last.content
    }
  }

  let reply = ""
  try {
    const { text } = await generateText({
      model: "openai/gpt-5-mini",
      prompt: `${promptBase}\n\nUser: ${userLatest}\nAssistant:`,
    })
    reply = text
  } catch (e) {
    // Simple local fallback: quick, practical guidance without external providers
    const q = String(userLatest || "").toLowerCase()
    const tips =
      "- Provide your from/to cities and dates for better options.\n- Flexible dates often reduce prices.\n- Off-peak hours can be cheaper.\n- Compare nearby airports or neighborhoods."
    if (q.includes("cancel")) {
      reply =
        "To cancel a booking, share your booking reference (e.g., BK-XXXX). Most fares allow cancellation within 24 hours. If you booked a hotel, check the property’s cancellation window."
    } else if (q.includes("change") || q.includes("modify")) {
      reply =
        "To change a booking, please provide your booking reference and the new dates or route. Changes may incur a fee depending on fare rules and availability."
    } else if (q.includes("baggage")) {
      reply =
        "Baggage policies vary by airline and fare. As a rule of thumb: 1 small personal item is free; carry-on or checked bags may require a fee on basic fares."
    } else if (q.includes("refund")) {
      reply =
        "Refunds depend on fare type and policy. Many basic fares are nonrefundable, but you may receive a credit. Share your booking reference and I’ll guide you."
    } else {
      reply = `Here are some quick tips:\n${tips}\n\nAsk me about flights, hotels, or an existing booking reference for more specific help.`
    }
  }

  return NextResponse.json({ reply })
}

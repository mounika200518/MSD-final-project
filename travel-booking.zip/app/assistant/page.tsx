import ChatBookingAssistant from "@/components/chat-booking-assistant"

export default function AssistantPage() {
  return (
    <main className="container mx-auto max-w-3xl p-6">
      <h1 className="text-2xl font-semibold mb-4 text-pretty">Travel Assistant</h1>
      <ChatBookingAssistant />
    </main>
  )
}

import ChatBookingAssistant from "@/components/chat-booking-assistant"

export default function Page() {
  return (
    <main className="max-w-5xl mx-auto p-6 space-y-6">
      <header className="space-y-1">
        <h1 className="text-2xl font-semibold text-foreground text-balance">Travel Booking Assistant</h1>
        <p className="text-sm text-muted-foreground">
          Ask me to book a flight, bus, or train. Example: {'"Book a flight from Mumbai to Delhi"'}
        </p>
      </header>
      <ChatBookingAssistant />
    </main>
  )
}

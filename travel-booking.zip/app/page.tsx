import { Suspense } from "react"
import ChatBookingAssistant from "@/components/chat-booking-assistant"

export default function Page() {
  return (
    <main className="min-h-dvh bg-background text-foreground">
      <div className="mx-auto w-full max-w-6xl px-4 py-8 md:py-10">
        <header className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/placeholder-logo.png" alt="Travel Booking" width={32} height={32} className="rounded-md" />
            <h1 className="text-pretty text-2xl font-semibold tracking-tight">Travel Booking</h1>
          </div>
        </header>

        <Suspense>
          <ChatBookingAssistant />
        </Suspense>

        <footer className="mt-10 border-t border-border pt-6 text-sm text-muted-foreground">
          <p className="text-pretty">{"Built with Next.js and shadcn/ui."}</p>
        </footer>
      </div>
    </main>
  )
}

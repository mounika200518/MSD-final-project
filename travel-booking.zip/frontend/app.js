// Simple SPA logic for the Travel Booker frontend

const els = {
  apiBase: document.getElementById("api-base"),
  apiSave: document.getElementById("save-api-base"),
  apiStatus: document.getElementById("api-status"),

  searchForm: document.getElementById("search-form"),
  name: document.getElementById("name"),
  email: document.getElementById("email"),
  source: document.getElementById("source"),
  destination: document.getElementById("destination"),
  date: document.getElementById("date"),
  passengers: document.getElementById("passengers"),

  results: document.getElementById("results"),
  selectedOption: document.getElementById("selected-option"),
  bookingForm: document.getElementById("booking-form"),
  bookBtn: document.getElementById("book-btn"),
  cardName: document.getElementById("card-name"),
  cardNumber: document.getElementById("card-number"),
  confirmation: document.getElementById("confirmation"),

  chatToggle: document.getElementById("chat-toggle"),
  chatPanel: document.getElementById("chat-panel"),
  chatClose: document.getElementById("chat-close"),
  chatMessages: document.getElementById("chat-messages"),
  chatForm: document.getElementById("chat-form"),
  chatText: document.getElementById("chat-text"),
}

let API_BASE = localStorage.getItem("apiBase") || els.apiBase.value || "http://localhost:5000"
els.apiBase.value = API_BASE

let CURRENT_RESULTS = []
let SELECTED_OPTION = null

// Health check
async function checkApi() {
  try {
    const res = await fetch(`${API_BASE}/health`)
    if (!res.ok) throw new Error("status " + res.status)
    const data = await res.json()
    els.apiStatus.textContent = `OK (${data.service})`
    els.apiStatus.style.color = "#22c55e"
  } catch (e) {
    els.apiStatus.textContent = "Unreachable"
    els.apiStatus.style.color = "#ef4444"
  }
}

// Save API base
els.apiSave.addEventListener("click", () => {
  const val = (els.apiBase.value || "").trim()
  if (!val) return
  API_BASE = val
  localStorage.setItem("apiBase", API_BASE)
  checkApi()
})

// Handle search
els.searchForm.addEventListener("submit", async (e) => {
  e.preventDefault()
  els.results.innerHTML = '<div class="muted">Searching...</div>'
  SELECTED_OPTION = null
  els.selectedOption.textContent = "No option selected yet."
  els.bookBtn.disabled = true
  els.confirmation.innerHTML = ""

  const payload = {
    source: els.source.value.trim(),
    destination: els.destination.value.trim(),
    date: els.date.value,
    passengers: Number(els.passengers.value || 1),
  }

  try {
    const res = await fetch(`${API_BASE}/api/search`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })
    const data = await res.json()
    if (!res.ok) throw new Error(data.error || "Search failed")
    CURRENT_RESULTS = data.options || []
    renderResults(CURRENT_RESULTS, payload.passengers)
  } catch (err) {
    console.error(err)
    els.results.innerHTML = `<div class="muted">Error: ${(err && err.message) || "Search failed"}</div>`
  }
})

function renderResults(options, passengers) {
  if (!options.length) {
    els.results.innerHTML = '<div class="muted">No results found. Try different details.</div>'
    return
  }
  els.results.innerHTML = ""
  for (const o of options) {
    const total = (o.price_per_seat * passengers).toFixed(2)
    const div = document.createElement("div")
    div.className = "option"
    div.innerHTML = `
      <h3>${o.mode} • ${o.operator}</h3>
      <div class="grid2">
        <div class="meta">
          <div><strong>${o.source}</strong> → <strong>${o.destination}</strong></div>
          <div>Depart: ${formatDT(o.departure)}</div>
          <div>Arrive: ${formatDT(o.arrival)}</div>
        </div>
        <div class="meta" style="text-align:right">
          <div>Duration: ${o.duration_minutes}m</div>
          <div><span class="badge">$${o.price_per_seat}/seat</span></div>
          <div>Seats: ${o.seats_available}</div>
        </div>
      </div>
      <div class="mt">
        <button class="btn primary select-btn">Select (Total $${total})</button>
      </div>
    `
    const btn = div.querySelector(".select-btn")
    btn.addEventListener("click", () => {
      SELECTED_OPTION = o
      highlightSelection(div)
      els.selectedOption.innerHTML = `
        <div><strong>Selected:</strong> ${o.mode} • ${o.operator}</div>
        <div>${o.source} → ${o.destination}</div>
        <div>Depart: ${formatDT(o.departure)} | Arrive: ${formatDT(o.arrival)}</div>
        <div>Price: $${o.price_per_seat}/seat</div>
      `
      els.bookBtn.disabled = false
      els.confirmation.innerHTML = ""
    })
    els.results.appendChild(div)
  }
}

function highlightSelection(selectedDiv) {
  const nodes = els.results.querySelectorAll(".option")
  nodes.forEach((n) => n.classList.remove("selected"))
  selectedDiv.classList.add("selected")
}

function formatDT(iso) {
  try {
    const d = new Date(iso)
    return d.toLocaleString()
  } catch {
    return iso
  }
}

// Handle booking
els.bookingForm.addEventListener("submit", async (e) => {
  e.preventDefault()
  if (!SELECTED_OPTION) return
  els.bookBtn.disabled = true
  els.bookBtn.textContent = "Processing..."

  const passengers = Number(els.passengers.value || 1)
  const payload = {
    option: SELECTED_OPTION,
    passenger: { name: els.name.value.trim(), email: els.email.value.trim() },
    passengers,
    payment: {
      method: "mock",
      nameOnCard: els.cardName.value.trim(),
      cardNumber: els.cardNumber.value.trim(),
    },
  }

  try {
    const res = await fetch(`${API_BASE}/api/book`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })
    const data = await res.json()
    if (!res.ok || !data.success) {
      throw new Error((data && (data.error || data.message)) || "Booking failed")
    }
    renderConfirmation(data.ticket)
  } catch (err) {
    console.error(err)
    els.confirmation.innerHTML = `<div class="muted">Error: ${(err && err.message) || "Booking failed"}</div>`
  } finally {
    els.bookBtn.disabled = false
    els.bookBtn.textContent = "Confirm & Pay"
  }
})

function renderConfirmation(ticket) {
  els.confirmation.innerHTML = `
    <div class="ticket">
      <h3>Booking Confirmed</h3>
      <div>PNR: <strong>${ticket.pnr}</strong></div>
      <div>Name: ${ticket.passenger_name}</div>
      <div>Email: ${ticket.passenger_email}</div>
      <div>Passengers: ${ticket.passengers}</div>
      <div class="mt"><strong>Itinerary</strong></div>
      <div>${ticket.itinerary.mode} • ${ticket.itinerary.operator}</div>
      <div>${ticket.itinerary.source} → ${ticket.itinerary.destination}</div>
      <div>Depart: ${formatDT(ticket.itinerary.departure)}</div>
      <div>Arrive: ${formatDT(ticket.itinerary.arrival)}</div>
      <div>Duration: ${ticket.itinerary.duration_minutes}m</div>
      <div class="mt"><strong>Seats</strong>: ${ticket.seats.join(", ")}</div>
      <div class="mt"><strong>Total</strong>: $${ticket.price.total} ${ticket.price.currency}</div>
    </div>
  `
}

// Chat widget behavior
els.chatToggle.addEventListener("click", () => {
  els.chatPanel.classList.toggle("hidden")
  els.chatPanel.setAttribute("aria-hidden", els.chatPanel.classList.contains("hidden") ? "true" : "false")
  if (!els.chatPanel.classList.contains("hidden")) {
    els.chatText.focus()
  }
})
els.chatClose.addEventListener("click", () => {
  els.chatPanel.classList.add("hidden")
  els.chatPanel.setAttribute("aria-hidden", "true")
})

els.chatForm.addEventListener("submit", async (e) => {
  e.preventDefault()
  const text = els.chatText.value.trim()
  if (!text) return

  addMsg("user", text)
  els.chatText.value = ""
  addMsg("assistant", "Thinking...", true)

  try {
    const res = await fetch(`${API_BASE}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text }),
    })
    const data = await res.json()
    replaceLastAssistant(data.reply || "Sorry, I could not reply right now.")
  } catch (e) {
    replaceLastAssistant("There was an error contacting the chat service.")
  }
})

function addMsg(role, text, pending = false) {
  const div = document.createElement("div")
  div.className = `msg ${role}`
  div.innerHTML = `
    <span class="who">${role === "user" ? "You" : "Assistant"}</span>
    <span class="bubble">${escapeHTML(text)}</span>
  `
  if (pending) div.dataset.pending = "true"
  els.chatMessages.appendChild(div)
  els.chatMessages.scrollTop = els.chatMessages.scrollHeight
}

function replaceLastAssistant(text) {
  const nodes = Array.from(els.chatMessages.querySelectorAll(".msg.assistant"))
  const last = nodes.reverse().find((n) => n.dataset.pending === "true")
  if (last) {
    last.querySelector(".bubble").textContent = text
    delete last.dataset.pending
  } else {
    addMsg("assistant", text)
  }
}

function escapeHTML(s) {
  return s.replace(
    /[&<>"']/g,
    (c) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;",
      })[c],
  )
}

// Initialize
checkApi()

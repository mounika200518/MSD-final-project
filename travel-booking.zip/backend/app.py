import os
import random
import string
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any

from flask import Flask, jsonify, request
from flask_cors import CORS
import requests

# Flask application setup
app = Flask(__name__)
# Enable CORS for all /api/* routes - this allows the separate frontend to call the backend locally
CORS(app, resources={r"/api/*": {"origins": "*"}})

# Utility: Random helpers
def random_pnr(length: int = 6) -> str:
    """
    Generate a random PNR consisting of uppercase letters and digits.
    """
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))

def random_price(mode: str) -> float:
    """
    Generate a randomized price based on mode of transport.
    """
    # Simple ranges per mode
    ranges = {
        "Bus": (10, 50),
        "Train": (25, 120),
        "Flight": (80, 500),
    }
    low, high = ranges.get(mode, (20, 100))
    return round(random.uniform(low, high), 2)

def random_seats() -> int:
    """
    Randomize number of available seats.
    """
    return random.randint(0, 60)

def random_operator(mode: str) -> str:
    """
    Generate a plausible operator name based on mode.
    """
    bus_ops = ["GoBus", "InterCity", "CityLink", "MetroStar", "BlueLine"]
    train_ops = ["National Rail", "FastTrack", "RailSwift", "TransNation"]
    flight_ops = ["SkyWays", "AeroJet", "CloudAir", "StarFly", "JetLine"]
    mapping = {
        "Bus": bus_ops,
        "Train": train_ops,
        "Flight": flight_ops
    }
    return random.choice(mapping.get(mode, ["TravelCo"]))

def generate_times(travel_date: str, min_hour: int = 5, max_hour: int = 22, duration_min: int = 60) -> Dict[str, Any]:
    """
    Given a YYYY-MM-DD date string, generate randomized departure and arrival times.
    """
    try:
        base_date = datetime.strptime(travel_date, "%Y-%m-%d")
    except ValueError:
        # Fall back to today if parsing fails
        base_date = datetime.now()

    dep_hour = random.randint(min_hour, max_hour)
    dep_minute = random.choice([0, 15, 30, 45])
    dep_time = base_date.replace(hour=dep_hour, minute=dep_minute, second=0, microsecond=0)

    # Random duration around the provided duration_min
    duration_minutes = duration_min + random.randint(-20, 120)
    arr_time = dep_time + timedelta(minutes=max(30, duration_minutes))

    return {
        "departure": dep_time.isoformat(),
        "arrival": arr_time.isoformat(),
        "duration_minutes": (arr_time - dep_time).seconds // 60
    }

def generate_trip_options(source: str, destination: str, travel_date: str, passengers: int) -> List[Dict[str, Any]]:
    """
    Synthesize a set of trip options for bus, train, and flight with randomized values.
    """
    modes = [
        {"mode": "Bus", "duration_hint": 180},
        {"mode": "Train", "duration_hint": 240},
        {"mode": "Flight", "duration_hint": 120},
    ]
    all_options: List[Dict[str, Any]] = []

    for m in modes:
        # Create a few options per mode
        for _ in range(3):
            t = generate_times(travel_date, duration_min=m["duration_hint"])
            seats = random_seats()
            price = random_price(m["mode"])
            # Ensure price accounts for number of passengers (total cost shown or per seat; here we show per seat)
            option = {
                "id": ''.join(random.choices(string.ascii_lowercase + string.digits, k=10)),
                "mode": m["mode"],
                "operator": random_operator(m["mode"]),
                "source": source,
                "destination": destination,
                "departure": t["departure"],
                "arrival": t["arrival"],
                "duration_minutes": t["duration_minutes"],
                "price_per_seat": price,
                "seats_available": seats,
                "currency": "USD",
            }
            # Optionally filter out sold-out options if you want only available ones
            if seats >= passengers:
                all_options.append(option)
            else:
                # Occasionally include near-sold-out to show realistic results
                if random.random() < 0.2:
                    all_options.append(option)

    # Shuffle for variety
    random.shuffle(all_options)
    return all_options

# API: Health check
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"ok": True, "service": "travel-booking-backend"}), 200

# API: Search for travel facilities
@app.route("/api/search", methods=["POST"])
def search_travel():
    """
    Accepts JSON:
    {
      "source": "CityA",
      "destination": "CityB",
      "date": "YYYY-MM-DD",
      "passengers": 1
    }
    Returns trip options with randomized seats, timings, and prices.
    """
    data = request.get_json(silent=True) or {}
    source = data.get("source", "").strip()
    destination = data.get("destination", "").strip()
    date = data.get("date", "").strip()
    passengers = int(data.get("passengers", 1))

    if not source or not destination or not date:
        return jsonify({"error": "source, destination, and date are required"}), 400

    options = generate_trip_options(source, destination, date, passengers)
    return jsonify({"options": options}), 200

# API: Booking confirmation and simulated payment
@app.route("/api/book", methods=["POST"])
def book_trip():
    """
    Accepts JSON:
    {
      "option": { ...selected_option_object... },
      "passenger": { "name": "John Doe", "email": "john@example.com" },
      "passengers": 1,
      "payment": {
         "method": "mock",
         "cardNumber": "4242 4242 4242 4242",
         "nameOnCard": "John Doe"
      }
    }
    Returns booking confirmation with PNR and ticket details.
    """
    data = request.get_json(silent=True) or {}
    option = data.get("option")
    passenger = data.get("passenger", {})
    passengers = int(data.get("passengers", 1))
    payment = data.get("payment", {})

    if not option or not passenger.get("name") or not passenger.get("email"):
        return jsonify({"error": "option, passenger.name, and passenger.email are required"}), 400

    # Simulate payment processing
    # For mock purposes, consider any provided payment object as success after a small delay
    time.sleep(0.6)
    payment_method = payment.get("method", "mock")
    if payment_method != "mock":
        # Ultra-simple validation stub
        card = payment.get("cardNumber", "")
        if len(card.replace(" ", "")) < 8:
            return jsonify({"error": "Invalid card number"}), 400

    # Generate PNR and ticket info
    pnr = random_pnr()
    # Generate random seat allocations
    seats: List[str] = []
    for _ in range(passengers):
        if option["mode"] == "Flight":
            row = random.randint(5, 35)
            seat_letter = random.choice(list("ABCDEF"))
            seats.append(f"{row}{seat_letter}")
        elif option["mode"] == "Train":
            coach = random.choice(["A", "B", "C", "D", "E"])
            seat_no = random.randint(1, 80)
            seats.append(f"{coach}-{seat_no}")
        else:
            seat_no = random.randint(1, 50)
            seats.append(str(seat_no))

    ticket = {
        "pnr": pnr,
        "passenger_name": passenger["name"],
        "passenger_email": passenger["email"],
        "passengers": passengers,
        "itinerary": {
            "mode": option["mode"],
            "operator": option["operator"],
            "source": option["source"],
            "destination": option["destination"],
            "departure": option["departure"],
            "arrival": option["arrival"],
            "duration_minutes": option["duration_minutes"],
        },
        "price": {
            "currency": option.get("currency", "USD"),
            "price_per_seat": option["price_per_seat"],
            "total": round(option["price_per_seat"] * passengers, 2),
        },
        "seats": seats,
        "status": "CONFIRMED",
    }

    return jsonify({"success": True, "pnr": pnr, "ticket": ticket}), 200

# API: AI Chatbot (Gemini) endpoint
@app.route("/api/chat", methods=["POST"])
def chat():
    """
    Accepts JSON:
    {
      "message": "User question",
      "history": [{"role":"user","content":"..."},{"role":"assistant","content":"..."}]
    }
    Uses Gemini API if GOOGLE_API_KEY is set. Otherwise returns a fallback response.
    """
    data = request.get_json(silent=True) or {}
    message = data.get("message", "").strip()
    history = data.get("history", [])  # unused except for potential future improvement
    if not message:
        return jsonify({"error": "message is required"}), 400

    api_key = os.getenv("GOOGLE_API_KEY")
    system_prompt = (
        "You are a helpful travel assistant. Provide concise, friendly answers. "
        "When asked about bookings, remind the user this chat is informational and the actual booking occurs via the app."
    )

    # If no API key, return a deterministic helpful stub so the app still works offline.
    if not api_key:
        reply = (
            "Hi! I’m your travel assistant. I can help with destinations, timing tips, "
            "and booking steps. To enable AI answers via Gemini, set GOOGLE_API_KEY in the backend."
        )
        return jsonify({"reply": reply, "model": "fallback", "usingGemini": False}), 200

    try:
        # Gemini Generative Language REST call
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key={api_key}"
        payload = {
            "contents": [
                {"parts": [{"text": system_prompt}]} ,
                {"parts": [{"text": message}]}
            ]
        }
        resp = requests.post(url, json=payload, timeout=20)
        resp.raise_for_status()
        data = resp.json()
        # Parse the returned text
        candidate = (data.get("candidates") or [{}])[0]
        content = candidate.get("content") or {}
        parts = content.get("parts") or [{}]
        text = parts[0].get("text", "").strip() or "I’m here to help with your travel questions!"
        return jsonify({"reply": text, "model": "gemini-1.5-flash-latest", "usingGemini": True}), 200
    except Exception as e:
        # Fall back gracefully on any error
        return jsonify({
            "reply": "I ran into an issue contacting the AI service. Please try again later.",
            "error": str(e),
            "usingGemini": False
        }), 200

if __name__ == "__main__":
    # Flask dev server
    port = int(os.getenv("PORT", "5000"))
    # Note: In production you would use a real WSGI server.
    app.run(host="0.0.0.0", port=port, debug=True)

# Travel Booking Backend (Flask)

A simple Flask backend that exposes endpoints for searching travel options, booking with simulated payments, and a Gemini-powered chatbot.

## Endpoints

- `GET /health` — Health check.
- `POST /api/search` — Search for trips.
  - Body: `{ "source": "CityA", "destination": "CityB", "date": "YYYY-MM-DD", "passengers": 1 }`
- `POST /api/book` — Confirm a booking (simulated payment).
  - Body: 
    \`\`\`
    {
      "option": { ...optionFromSearch... },
      "passenger": { "name": "John Doe", "email": "john@example.com" },
      "passengers": 1,
      "payment": { "method": "mock", "cardNumber": "4242 4242 4242 4242", "nameOnCard": "John Doe" }
    }
    \`\`\`
- `POST /api/chat` — AI chatbot using Gemini. Set `GOOGLE_API_KEY` to enable, otherwise returns a safe fallback.

## Setup

1. Create a virtual environment and install dependencies:
   - `python -m venv .venv`
   - `source .venv/bin/activate` (Windows: `.venv\\Scripts\\activate`)
   - `pip install -r requirements.txt`
2. (Optional) Copy `.env.example` to `.env` and set `GOOGLE_API_KEY`.
3. Run the app:
   - `python app.py`
   - The server runs at `http://localhost:5000`.

CORS is enabled for all `/api/*` routes so a separate frontend can communicate with this backend.
